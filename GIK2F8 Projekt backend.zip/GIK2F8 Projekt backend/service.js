const express = require('express');
const ex = require('./express');
const { route } = require('./routes');
const routes = require('./routes');

const app = express();

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use('/public/', express.static('./upload'));
app.use('/api/', routes);
app.use(express.static('public'));
app.listen(3000,() => {
    console.log('Lyssnar nu på port 3000');
});