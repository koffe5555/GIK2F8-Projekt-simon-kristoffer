DROP TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS users (
    email varchar(128) UNIQUE NOT NULL,
    firstname varchar(32) NOT NULL,
    lastname varchar(32) NOT NULL,
    user_type INTEGER CHECK(user_type < 3),
    password varchar(128),
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE);

INSERT INTO users (email,firstname,lastname,password,user_type) VALUES
    ('h18votur@du.se', 'Volkan', 'Türkkan', 'hejhej', 0),
    ('h19kripa@du.se', 'Kristoffer', 'Palmgren', 'weeb', 1),
    ('h19linwe@du.se', 'Linus', 'Westerback', 'bigBoi', 2),
    ('h19simry@du.se', 'Simon', 'Rydvall', 'google', 2);

DROP TABLE IF EXISTS question;
CREATE TABLE IF NOT EXISTS question (
    title varchar(32) NOT NULL,
    text varchar(128) NOT NULL,
    date INTEGER NOT NULL,
    category varchar(32) NOT NULL,
    question_key INTEGER,
    FOREIGN KEY(question_key) REFERENCES users(id)
);

INSERT INTO question (title, text, date, category, question_key) VALUES
    ('Help', 'can someone help me', datetime('now','localtime'), 'FAQ', 1);

DROP TABLE IF EXISTS answer;
CREATE TABLE IF NOT EXISTS answer(
    answertext varchar(128) NOT NULL,
    date INTEGER NOT NULL,
    answer_key INTEGER,
    FOREIGN KEY(answer_key) REFERENCES users(id)

);

INSERT INTO answer (asnwertext, date, answer_key) VALUES
    ('use stack overflow', datetime('now','localtime'), 1);



