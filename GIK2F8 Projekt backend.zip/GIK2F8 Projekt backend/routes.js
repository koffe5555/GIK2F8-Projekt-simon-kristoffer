const routes = require('express').Router();
const dbService = require('./database');
const { PRIORITY_ABOVE_NORMAL } = require('constants');


//GET ALL QUESTIONS
routes.get('/question/', async(req,res)=>{
    try{
        const quest = await dbService.GetAllQuestions();
        res.send(quest);
    }
    catch(error)
    {
        res.send('Could not get the questions from the database!')
    }
});

//GET ALL ANSWERS
routes.get('/answer/', async(req,res)=>{
    try{
        const answer = await dbService.GetAllAnswers();
        res.send(answer);
    }
    catch(error)
    {
        res.send('Could not get the answers from the database!')
    }
});


//GET QUESTION BY ID
routes.get('/question/:id', async (req,res)=>{
    if(isNaN(req.params.id) == true)
    {
        res.send('Enter a number!')
    }
    else
    {
        try 
        {
            const id = req.params.id;
            const prod = await dbService.GetQuestionId(id);
            res.send(prod);
        }
        catch(error)
        {
            res.send('Could not get the question from the database!');
        }
    }

});

//DELETE QUESTION BY ID
routes.delete('/question/:id', async (req,res)=>{
    if(isNaN(req.params.id) == true)
    {
        res.send('Enter a number!')
    }
    else{
        try 
        {
            const id = req.params.id;
            const prod = await dbService.DeleteQuestion(id);
            res.send({'status' : 'ok'});
        }
        catch(error)
        {
            res.send('Could not Delete the question!');
        }
    }

});

//DELETE ANSWER
routes.delete('/answer/:id', async (req,res)=>{
    if(isNaN(req.params.id) == true)
    {
        res.send('Enter a number!')
    }
    else{
        try 
        {
            const id = req.params.id;
            const prod = await dbService.DeleteAnswer(id);
            res.send({'status' : 'ok'});
        }
        catch(error)
        {
            res.send('Could not Delete the question!');
        }
    }
});

//GET ANSWER ID
routes.get('/answer/:id', async (req,res)=>{
    if(isNaN(req.params.id) == true)
    {
        res.send('Enter a number!')
    }
    else
    {
        try 
        {
            const id = req.params.id;
            const prod = await dbService.GetAnswer(id);
            res.send(prod);
        }
        catch(error)
        {
            res.send('Could not get the question from the database!');
        }
    }

});

//POST QUESTION
routes.post('/question/', async (req,res)=>{
    
    try{
        const question = await dbService.PostQuestion(req.body);
        res.send(question);
    }
    catch(error)
    {
        res.send('Could not post the question to the database!');
    }
});

//POST ANSWER
routes.post('/answer/', async (req,res)=>{
    
    try{
        const question = await dbService.PostAnswer(req.body);
        res.send(question);
    }
    catch(error)
    {
        res.send('Could not post the question to the database!');
    }
});

//UPDATE QUESTION
routes.put('/question/', async (req,res) => {
    if(req.body.name == 0 || req.body.description == 0 || req.body.price == 0 || req.body.id == 0)
    {
        res.send('Please fill in all fields');
    }
    else
    {
        try
        {
            const update = await dbService.UpdateQuestion(req.body)
            res.send({'status' : 'ok'});
                        
        }
        catch(error)
        {
            res.send('Could not update the product!');
        }
    }
});

//UPDATE ANSWWER
routes.put('/answer/', async (req,res) => {
    if(req.body.name == 0 || req.body.description == 0 || req.body.price == 0 || req.body.id == 0)
    {
        res.send('Please fill in all fields');
    }
    else
    {
        try
        {
            const update = await dbService.UpdateAnswer(req.body)
            res.send({'status' : 'ok'});
                        
        }
        catch(error)
        {
            res.send('Could not update the product!');
        }
    }
});

//LOGIN
routes.post('/login/', async (req,res) => {
    const email = req.body.email.match(/^[A-Za-z]+$/)
    const password = req.body.email.match(/^[0-9A-Za-z]+$/)

    if(email != null || password != null) {
        res.send('Enter email and password correct!')
    }
    else
    {
        try 
        {
            const user = await dbService.login(req.body);
            if(user.length == 0)
            {
                res.send('Wrong email or passowrd!')
            }
            else{
                res.json(user)
            }
        }
        catch(error)
        {
            res.send(error)
        }
    }
   
});

module.exports = routes;