const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const { stat } = require('fs');


const dbPromise = (async () => {
    return open ({
        filename: './database.sqlite',
        driver: sqlite3.Database
    });
})();

//LOGIN
const login = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const user = dbCon.all('SELECT firstname, lastname, id FROM users WHERE email = ? AND password = ?',[data.email,data.password]);
        return user;
    }
    catch(error)
    {
        throw error;
    }
};
 
//GET ALL QUESTIONS
const GetAllQuestions = async () => {
    try{
        const dbCon = await dbPromise;
        const all = await dbCon.all('SELECT * FROM question ORDER BY title DESC');
        return all;
    }
    catch(error){
        console.log('Could not get the questions from the database!')
    }
}

//GET ALL ANSWERS
const GetAllAnswers = async () => {
    try{
        const dbCon = await dbPromise;
        const all = await dbCon.all('SELECT * FROM answer ORDER BY answertext DESC');
        return all;
    }
    catch(error){
        console.log('Could not get the questions from the database!')
    }
}

//GET QUESTION ID
const GetQuestionId = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prod =  dbCon.get('SELECT * FROM question WHERE question_key = ?', [data]);
        return prod;
    }
    catch(error)
    {
        console.log('Could not get product id from database!')
    }
};

//DELETE QUESTION ID
const DeleteQuestion = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prodDelete = dbCon.get('DELETE FROM question WHERE question_key = ?', [data]);
        return prodDelete;
    }
    catch (error)
    {
        console.log('Could not delete id from database!')
    }
};

//DELETE ANSWER ID
const DeleteAnswer = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prodDelete = dbCon.get('DELETE FROM answer WHERE answer_key = ?', [data]);
        return prodDelete;
    }
    catch (error)
    {
        console.log('Could not delete id from database!')
    }
};

//GET ANSWER ID
const GetAnswer = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prod =  dbCon.get('SELECT * FROM answer WHERE answer_key = ?', [data]);
        return prod;
    }
    catch(error)
    {
        console.log('Could not get product id from database!')
    }
};
//POST QUESTION WITH FK
const PostQuestion = async (data) => {
    try{
        const dbCon = await dbPromise;
        const quest = dbCon.run('INSERT INTO question (title, text, date, category, question_key) VALUES(?, ?, ?, ?, ?)', [data.title, data.text, data.date, data.category, data.question_key]);
        return {status: 'ok'};
    }
    catch(error)
    {
        console.log('Could not post to the database!')
    }
};
//POST ANSWER FK
const PostAnswer = async (data) => {
    try{
        const dbCon = await dbPromise;
        const quest = dbCon.run('INSERT INTO answer (answertext, date, answer_key) VALUES(?, ?, ?)', [data.answertext, data.date, data.answer_key]);
        return {status: 'ok'};
    }
    catch(error)
    {
        console.log('Could not post to the database!')
    }
};

//UPDATE QUESTION
const UpdateQuestion = async(data) => {
    try
    {
        const dbCon = await dbPromise;
        await dbCon.run('UPDATE question SET title = ?, text = ?, date = ?, category=? WHERE question_key = ?',[data.title, data.text,data.date,data.category, data.question_key]);
    }
    catch(error)
    {
        console.log('Could not update product in database!');
    }
};

//UPDATE ANSWER
const UpdateAnswer = async(data) => {
    try
    {
        const dbCon = await dbPromise;
        await dbCon.run('UPDATE answer SET answertext = ?, date = ? WHERE answer_key = ?',[data.answertext, data.date, data.answer_key]);
    }
    catch(error)
    {
        console.log('Could not update product in database!');
    }
};

module.exports = {
    login: login,
    GetQuestionId: GetQuestionId,
    DeleteQuestion: DeleteQuestion,
    DeleteAnswer : DeleteAnswer,
    GetAnswer : GetAnswer,
    PostQuestion : PostQuestion,
    PostAnswer : PostAnswer,
    UpdateQuestion : UpdateQuestion,
    UpdateAnswer : UpdateAnswer,
    GetAllAnswers : GetAllAnswers,
    GetAllQuestions : GetAllQuestions
};